﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ProgrammingInCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Money m = new Money(12.32M);
            // decimal amount = m;
            // int a = (int)m;
            // Console.Write(amount);
            // Console.Write(a);
            // IAnimal animal = new Dog();
            // animal.Run();

            // List<Order> orders = new List<Order>
            // {
            //     new Order { CreatedDate = new DateTime(2012, 12, 1 )},
            //     new Order { CreatedDate = new DateTime(2012, 1, 6 )},
            //     new Order { CreatedDate = new DateTime(2012, 7, 8 )},
            //     new Order { CreatedDate = new DateTime(2012, 2, 20 )},
            // };
            // orders.Sort();

            // string patterns = "(Mr\\.? |Mrs\\.? |Miss |Ms\\.? )";
            // string[] names = { "Mr. Bruce Wayne", "Mrs. Clark Kent", "Miss Abc Xyz", "Ms. Nicole Norris" };

            // foreach (var name in names)
            // {
            //     Console.WriteLine(Regex.Replace(name, patterns, string.Empty));
            // }

            // Listing 4-1 Pg. 254
            // DriveInfoSample(); 

            // Listing 4-5 Building a directory tree
            // DirectoryInfo directoryInfo = new DirectoryInfo(@"C:\Program Files");
            // ListDirectories(directoryInfo, "*a*", 5, 0);

            // Listing 4-14 Create and use FileStream
            // UsingFileStream();

            // Listing 4-15 Using File.CreateText with a StreamWriter
            // UsingStreamWriter();

            // Listing 4-32 Executing a SQL Command
            //ReadDataFromTable();

            // Listing 4-34 Updating rows with ExecuteNonQuery
            //UpdateTable();

            // Listing 4-35 Inserting values with a parameterized query
            InsertWithParameters("Bruce", "Wayne");
            Console.ReadKey();
        }

        private static void UpdateTable()
        {
            string connString = ConfigurationManager.ConnectionStrings["Test"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connString))
            {
                SqlCommand cmd = new SqlCommand("Update persons set FirstName = 'Vivek', LastName = 'Parekh'", conn);
                conn.Open();
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                Console.WriteLine("{0} rows affected ", noOfRowsAffected);
            }
        }

        private static void InsertWithParameters(string firstName, string lastName)
        {
            string connString = ConfigurationManager.ConnectionStrings["Test"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connString))
            {
                SqlCommand cmd = new SqlCommand("Insert into persons ([FirstName], [LastName]) values (@firstName, @lastName)", conn);
                conn.Open();
                cmd.Parameters.Add(new SqlParameter("@firstName", firstName));
                cmd.Parameters.Add(new SqlParameter("@lastName", lastName));
                int noOfRowsAffected = cmd.ExecuteNonQuery();
                Console.WriteLine("{0} rows affected ", noOfRowsAffected);
            }
        }
        private static void ReadDataFromTable()
        {
            string connString = ConfigurationManager.ConnectionStrings["Test"].ConnectionString;

            try
            {
                using (SqlConnection conn = new SqlConnection(connString))
                {
                    //SqlCommand command = new SqlCommand("select * from persons;", conn);
                    SqlCommand command = new SqlCommand(@"select * from persons;
                    Select top 1 * from persons order by id desc", conn); // multiple commands
                    bool isMultipleQuery = true;

                    conn.Open();

                    SqlDataReader reader = command.ExecuteReader();
                    if (!isMultipleQuery)
                    {

                        while (reader.Read())
                        {
                            string personWithMiddleName = "Person {0} is {1} {2} {3}";
                            string personWithoutMiddleName = "Person {0} is {1} {2}";

                            string id = Convert.ToString(reader["Id"]);
                            string firstName = Convert.ToString(reader["FirstName"]);
                            string middleName = Convert.ToString(reader["MiddleName"]);
                            string lastName = Convert.ToString(reader["LastName"]);

                            if (string.IsNullOrEmpty(middleName))
                            {
                                Console.WriteLine(personWithoutMiddleName, id, firstName, lastName);
                            }
                            else
                            {
                                Console.WriteLine(personWithMiddleName, id, firstName, middleName, lastName);
                            }

                        }
                        reader.Close();
                    }
                    else
                    {
                        OutputResultSet(reader);
                        reader.NextResult();
                        OutputResultSet(reader);
                        reader.Close();
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public static void OutputResultSet(SqlDataReader reader)
        {
            while (reader.Read())
            {
                string personWithMiddleName = "Person {0} is {1} {2} {3}";
                string personWithoutMiddleName = "Person {0} is {1} {2}";

                string id = Convert.ToString(reader["Id"]);
                string firstName = Convert.ToString(reader["FirstName"]);
                string middleName = Convert.ToString(reader["MiddleName"]);
                string lastName = Convert.ToString(reader["LastName"]);

                if (string.IsNullOrEmpty(middleName))
                {
                    Console.WriteLine(personWithoutMiddleName, id, firstName, lastName);
                }
                else
                {
                    Console.WriteLine(personWithMiddleName, id, firstName, middleName, lastName);
                }

            }
        }


        private static void ListDirectories(DirectoryInfo directoryInfo,
        string searchPattern, int maxLevel, int currentLevel)
        {
            if (currentLevel >= maxLevel)
            {
                return;
            }
            string indent = new string('-', currentLevel);
            try
            {
                DirectoryInfo[] subDirectories = directoryInfo.GetDirectories(searchPattern);
                foreach (DirectoryInfo subDirectory in subDirectories)
                {
                    Console.WriteLine(indent + subDirectory.Name);
                    ListDirectories(subDirectory, searchPattern, maxLevel, currentLevel + 1);
                }
            }
            catch (UnauthorizedAccessException)
            {
                // You don’t have access to this folder.
                Console.WriteLine(indent + "Can’t access: " + directoryInfo.Name);
                return;
            }

            catch (DirectoryNotFoundException)
            {
                // The folder is removed while iterating
                Console.WriteLine(indent + "Can’t find: " + directoryInfo.Name);
                return;
            }
        }

        public static void UsingFileStream()
        {
            string path = Path.GetTempFileName();

            using (FileStream stream = File.Create(path))
            {
                var text = "Hello File";
                byte[] data = Encoding.UTF8.GetBytes(text);
                stream.Write(data, 0, data.Length);
            }

            using (FileStream stream = File.OpenRead(path))
            {
                byte[] data = new byte[stream.Length];
                for (int i = 0; i < stream.Length; i++)
                {
                    data[i] = Convert.ToByte(stream.ReadByte());
                }
                Console.WriteLine("File content is {0}", Encoding.UTF8.GetString(data));
            }
        }

        public static void UsingStreamWriter()
        {
            string path = Path.GetTempFileName();

            using (StreamWriter streamWriter = File.CreateText(path))
            {
                var text = "Hello File";
                streamWriter.Write(text);
            }

            using (StreamReader reader = File.OpenText(path))
            {
                Console.WriteLine(reader.ReadToEnd());
            }
        }

        private static void DriveInfoSample()
        {
            DriveInfo[] drivesInfo = DriveInfo.GetDrives();
            foreach (DriveInfo driveInfo in drivesInfo)
            {
                Console.WriteLine("Drive {0}", driveInfo.Name);
                Console.WriteLine(" File type: {0}", driveInfo.DriveType);
                if (driveInfo.IsReady == true)
                {
                    Console.WriteLine(" Volume label: {0}", driveInfo.VolumeLabel);
                    Console.WriteLine(" File system: {0}", driveInfo.DriveFormat);
                    Console.WriteLine(
                    " Available space to current user:{0, 15} bytes",
                    driveInfo.AvailableFreeSpace);
                    Console.WriteLine(
                    " Total available space: {0, 15} bytes",
                    driveInfo.TotalFreeSpace);
                    Console.WriteLine(
                    " Total size of drive: {0, 15} bytes ",
                    driveInfo.TotalSize);
                }
            }
        }
    }

    class Order : IComparable
    {
        public DateTime CreatedDate { get; set; }

        public int CompareTo(object obj)
        {
            if (obj == null) return 1;

            Order order = obj as Order;

            if (order == null)
            {
                Console.Write("Object is not order");
            }

            return this.CreatedDate.CompareTo(order.CreatedDate);
        }
    }



    interface IAnimal
    {
        void Run();
    }

    class Dog : IAnimal
    {

        public void Bark() { }
        public void Run() { }
    }


    public class Money
    {
        public decimal Amount { get; set; }

        public Money(decimal amount)
        {
            Amount = amount;
        }

        public static implicit operator decimal(Money money)
        {
            return money.Amount;
        }

        public static explicit operator int(Money money)
        {
            return (int)money.Amount;
        }
    }
}
